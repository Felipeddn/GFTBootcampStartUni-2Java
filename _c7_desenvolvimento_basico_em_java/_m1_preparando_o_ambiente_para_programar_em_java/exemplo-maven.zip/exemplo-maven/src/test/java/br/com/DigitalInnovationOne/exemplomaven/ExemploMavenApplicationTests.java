package br.com.DigitalInnovationOne.exemplomaven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExemploMavenApplicationTests {

	@Test
	void contextLoads() {
	}

}
